# mypackage
This library is created as an example

## Building the package locally
'python setup.py sdist'

##  installing this package from github
'pip install git+https://github.com/SamGumede/example-python-package.git'

## update this package from github
'pip install --upgrade git+https://github.com/SamGumede/example-python-package.git'
